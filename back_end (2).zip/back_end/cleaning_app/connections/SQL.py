import pandas as pd





def sqlfiletodf(file,type):
    