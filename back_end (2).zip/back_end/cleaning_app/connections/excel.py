import sys
import os
import io
from django.http import HttpResponse
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.append(parent_dir)
import pandas as pd
from cleaning_app.cleaning.clean import clean



def excel(file,type,Outlier=True):
    if type=='.csv':
        print("cleaning started for excel")
        df = pd.read_csv(file)
        new_df = pd.DataFrame(df)
        new_df = clean(new_df,type=type,outlier=Outlier)
        excel_buffer = io.BytesIO()
        new_df.to_excel(excel_buffer, index=False)
        excel_buffer.seek(0)
        response = HttpResponse(excel_buffer.getvalue(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        return response
    else:
        df = pd.read_excel(file)
        new_df = pd.DataFrame(df)
        new_df = clean(new_df,type=type,outlier=Outlier)
        excel_buffer = io.BytesIO()
        new_df.to_excel(excel_buffer, index=False)
        excel_buffer.seek(0)
        response = HttpResponse(excel_buffer.getvalue(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response["Access-Control-Allow-Origin"] = "http://localhost:3000"  # Adjust the origin as needed
        response["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        response["Access-Control-Allow-Headers"] = "*"
        return response
        


