import sys
import os
import io
from django.http import HttpResponse, HttpResponseServerError
import pandas as pd
from cleaning_app.cleaning.clean import clean

def flatten_json(json_data):
    flattened_data = []
    for entry in json_data:
        flattened_entry = {}
        _flatten(entry, '', flattened_entry)
        flattened_data.append(flattened_entry)
    return flattened_data

def _flatten(entry, parent_key, flattened_data):
    for key, value in entry.items():
        new_key = f"{parent_key}_{key}" if parent_key else key
        if isinstance(value, dict):
            _flatten(value, new_key, flattened_data)
        else:
            # Convert non-dictionary values to strings
            flattened_data[new_key] = str(value)

def mongo_connected(file, Outlier=True):
    try:
        json_data = pd.read_json(file)
        flattened_data = flatten_json(json_data)
        df = pd.DataFrame(flattened_data)
        cleaned_data = clean(df, type=type, outlier=Outlier)
        json_response = cleaned_data.to_json(orient='records')
        response = HttpResponse(json_response, content_type='application/json')
        response['Content-Disposition'] = 'attachment; filename="output.json"'
        return response
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return HttpResponseServerError("An error occurred while processing the data")
