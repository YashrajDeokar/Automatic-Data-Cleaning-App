import mysql.connector
import pandas as pd
import sys
import os
import io
from django.http import HttpResponse
from django.shortcuts import render,HttpResponse
from django.utils.text import slugify  # Import slugify function to generate a valid worksheet name

parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.append(parent_dir)
from cleaning_app.cleaning.clean import clean

def connectSQL(host, username, password, database,request,Outlier=True):
    try:
        db = mysql.connector.connect(
            host=host,
            user=username,
            password=password,
            database=database
        )
        database_cursor = db.cursor()
        database_cursor.execute("SHOW TABLES")
        tables = database_cursor.fetchall()
        if db.is_connected():
            print("Database is connected")
            excel_buffer = io.BytesIO()
            with pd.ExcelWriter(excel_buffer, engine='xlsxwriter') as writer:
                for table in tables:
                    table_name = table[0]  # The table name is the first element of the tuple
                    # Generate a valid worksheet name using slugify and truncating to 31 characters
                    worksheet_name = slugify(table_name)[:29]  # Adjust length according to your needs
                    query = "SELECT * FROM `{}`".format(table_name)
                    df = pd.read_sql(query, db)
                    new_df = clean(df=df, type="sql",outlier=Outlier)
                    new_df.to_excel(writer, sheet_name=worksheet_name, index=False)
            excel_buffer.seek(0)
            

        # Prepare the response to download the Excel file
            response = HttpResponse(excel_buffer.getvalue(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            return response
        else:
            print("Something went wrong")
    except mysql.connector.Error as err:
        print("MySQL Error:", err)
    finally:
        if 'db' in locals() and db.is_connected():
            database_cursor.close()
            db.close()

# Example usage:
# connectSQL(host="localhost", username="your_username", password="your_password", database="your_database_name")
