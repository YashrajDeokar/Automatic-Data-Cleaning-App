from zipfile import ZipFile


def zipTheFile(dfs):
    zipObj = ZipFile("data.zip",'w')
    for df in range(0..len(dfs)):
        zipObj.write(df)

    zipObj.close()

    