from django.shortcuts import render,HttpResponse

import sys
import os
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.append(parent_dir)
from cleaning_app.connections.excel import excel
from cleaning_app.connections.sql_connection import connectSQL
from cleaning_app.connections.mongodb_connection import mongo_connected
import pandas as pd
# Create your views here.

def cleaningAlgo(request):
    if request.method == 'POST':
          if request.POST['key']=='Excel':
               file_type=request.POST['type']
               print("starting the excel process")
               return excel(file=request.FILES['file'], type=file_type,Outlier=request.POST.get("outlier", False))
          elif request.POST['key']=='Sql':
               print("running sql connections")
               username = request.POST.get('SQL_username')
               password = request.POST.get('password')
               database = request.POST.get('database')
               host = request.POST.get('host')
               return connectSQL(host=host,password=password,username=username,database=database,request=request,Outlier=request.POST.get("outlier", False))
          elif request.POST['key']=='Mongo':
               url = request.POST.get('url')
               database = request.POST.get('database')
               return mongo_connected(file=request.FILES['file_json'],Outlier=request.POST.get("outlier", False))
     
          print("printing the details")
          print(request.POST)
          print(request.FILES)
          return HttpResponse("this is the ddata cleaning app",request)
    else:
          return HttpResponse("this is the ddata cleaning app",request)
         
         

