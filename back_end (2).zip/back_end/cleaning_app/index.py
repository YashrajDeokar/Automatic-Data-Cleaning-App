


def index():
    return 0