import pandas as pd
import sys
import os
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.append(parent_dir)
from  cleaning_app.cleaning.knn import find_unknown

def checkNull(df):
   
    null_vals = df.isnull().sum()
    for null_val in null_vals:
        if null_val != 0:
            return True
        
    return False
def handling_null(df):
    print("handling null values")
    columns = df.columns.tolist()
    if checkNull(df):
        df=df.interpolate()
        
    if checkNull(df):
        for i in range(0,len(columns)):
            if df[columns[i]].isnull().sum()>0 and str(df[columns[i]].dtype)=='int64':
                df[columns[i]].fillna(df[columns[i]].mean())
            
    if checkNull(df):
        x=[]
        y=[]
        for i in range(0,len(columns)):
            if df[columns[i]].dtype=='object' and df[columns[i]].isnull().sum()>0:
                y.append(columns[i])
                for i in range(0,len(columns)):
                    if df[columns[i]].isnull().sum()==0 and df[columns[i]].dtype =='int64' or df[columns[i]].dtype =='float64':
                        x.append(columns[i])
                find_unknown(df=df,x=x,y=y)
                x=[]
                y=[]
    df=df.dropna()
    print(df)
    return df

                





        
     
            
                

    
    print("NUll values:")
    print(df.isnull().sum())
    return df
    