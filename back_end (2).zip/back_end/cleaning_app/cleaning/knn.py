import pandas as pd
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.preprocessing import LabelEncoder
import numpy as np


def find_unknown(df, x, y):
    # try:
       
        newdf = df
        newdf=newdf.dropna()
        # Split data into train and test sets
        X_train, X_test, y_train, y_test = train_test_split(newdf[x], newdf[y], test_size=0.2, random_state=42)
        
        # Fit a KNeighborsRegressor model
        label_encoder=LabelEncoder()
        print("Printing shape\n",y)
        y_encode = np.ravel(y_train)
        label_encoder.fit(y_encode)
        y_train_transform=label_encoder.transform(y_encode)
        
       
        rf_regressor = SVC()  
        rf_regressor.fit(X_train,y_train_transform )  
        
        # Predict missing values
        y_pred = rf_regressor.predict(X_test)
      


        # Impute missing values in y column
        # for i in range(df.shape[0]):
            
        #     if len(str(df[y].iloc[i]))<=42 or str(df[y].iloc[i]) =="nan":
        #         print("cond satisfy")
        #         predicted_value = rf_regressor.predict(pd.DataFrame(df[x]))
        #         encoded_value=label_encoder.inverse_transform([predicted_value])
        #         df.at[i, y] = encoded_value[0]
        #         print("Predicted data at index", i, "is:", predicted_value)
        predicted_value = rf_regressor.predict(pd.DataFrame(df[x]))
        encoded_value=label_encoder.inverse_transform(pd.DataFrame(predicted_value))
        df[y]=pd.DataFrame(encoded_value)
      

           
          
    # except Exception as e:
    #     print("An error occurred:", e)
    # return df
        return df
