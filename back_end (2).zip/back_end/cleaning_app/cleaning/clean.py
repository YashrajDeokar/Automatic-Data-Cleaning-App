
import sys
import os
import pandas as pd
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.append(parent_dir)
from cleaning_app.cleaning.duplicate_values import duplicate_values
from cleaning_app.cleaning.handling_null import handling_null
from cleaning_app.cleaning.outliears import remove_outliers


def clean(df,type,outlier=True):
    if type==".csv":
        print("working....")
        df=duplicate_values(df)
        df=handling_null(df)
        if outlier:
            df=remove_outliers(df)
            pass
        return df
    elif(type=="excel"):
        df=duplicate_values(df)
        df=handling_null(df)
        if outlier:
            df=remove_outliers(df)
            pass
        return df
    elif(type=="sql"):
        df=duplicate_values(df)
        df=handling_null(df)
        if outlier:
            df=remove_outliers(df)
            pass
        return df
    elif(type=="mongo"):
        df=duplicate_values(df)
        df=handling_null(df)
        if outlier:
            df=remove_outliers(df)
            pass
        return df





