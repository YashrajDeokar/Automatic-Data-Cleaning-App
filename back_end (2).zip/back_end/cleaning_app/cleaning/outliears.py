import pandas as pd

def find_outliers(column):
    q1 = column.quantile(0.25)
    q3 = column.quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - (1.5 * iqr)
    upper_bound = q3 + (1.5 * iqr)
    outliers = (column < lower_bound) | (column > upper_bound)
    return outliers

def remove_outliers(df):
    for column in df.columns:
        if df[column].dtype == 'int64' or df[column].dtype == 'float64':
            outliers_mask = find_outliers(df[column])
            # Apply the mask to keep non-outliers
            df = df[~outliers_mask]
    return df
