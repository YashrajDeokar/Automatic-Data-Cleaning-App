import pandas as pd



def duplicate_values(df):
    print("removing duplicate values")
    df.drop_duplicates()
    return df